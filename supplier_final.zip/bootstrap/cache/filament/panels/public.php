<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.public.resources.vendor-resource.pages.create-vendor' => 'App\\Filament\\Public\\Resources\\VendorResource\\Pages\\CreateVendor',
    'app.filament.public.resources.vendor-resource.pages.edit-vendor' => 'App\\Filament\\Public\\Resources\\VendorResource\\Pages\\EditVendor',
    'app.filament.public.resources.vendor-resource.pages.list-vendors' => 'App\\Filament\\Public\\Resources\\VendorResource\\Pages\\ListVendors',
    'app.filament.public.resources.vendor-resource.pages.view-vendor' => 'App\\Filament\\Public\\Resources\\VendorResource\\Pages\\ViewVendor',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament/Public/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Public\\Pages',
  ),
  'resources' => 
  array (
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Public\\Resources\\VendorResource.php' => 'App\\Filament\\Public\\Resources\\VendorResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament/Public/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Public\\Resources',
  ),
  'widgets' => 
  array (
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament/Public/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Public\\Widgets',
  ),
);