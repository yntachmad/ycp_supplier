<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.bank-resource.pages.create-bank' => 'App\\Filament\\Resources\\BankResource\\Pages\\CreateBank',
    'app.filament.resources.bank-resource.pages.edit-bank' => 'App\\Filament\\Resources\\BankResource\\Pages\\EditBank',
    'app.filament.resources.bank-resource.pages.list-banks' => 'App\\Filament\\Resources\\BankResource\\Pages\\ListBanks',
    'app.filament.resources.bank-resource.pages.view-bank' => 'App\\Filament\\Resources\\BankResource\\Pages\\ViewBank',
    'app.filament.resources.category-resource.pages.create-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\CreateCategory',
    'app.filament.resources.category-resource.pages.edit-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\EditCategory',
    'app.filament.resources.category-resource.pages.list-categories' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\ListCategories',
    'app.filament.resources.category-resource.pages.view-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\ViewCategory',
    'app.filament.resources.city-resource.pages.create-city' => 'App\\Filament\\Resources\\CityResource\\Pages\\CreateCity',
    'app.filament.resources.city-resource.pages.edit-city' => 'App\\Filament\\Resources\\CityResource\\Pages\\EditCity',
    'app.filament.resources.city-resource.pages.list-cities' => 'App\\Filament\\Resources\\CityResource\\Pages\\ListCities',
    'app.filament.resources.city-resource.pages.view-city' => 'App\\Filament\\Resources\\CityResource\\Pages\\ViewCity',
    'app.filament.resources.classification-resource.pages.create-classification' => 'App\\Filament\\Resources\\ClassificationResource\\Pages\\CreateClassification',
    'app.filament.resources.classification-resource.pages.edit-classification' => 'App\\Filament\\Resources\\ClassificationResource\\Pages\\EditClassification',
    'app.filament.resources.classification-resource.pages.list-classifications' => 'App\\Filament\\Resources\\ClassificationResource\\Pages\\ListClassifications',
    'app.filament.resources.classification-resource.pages.view-classification' => 'App\\Filament\\Resources\\ClassificationResource\\Pages\\ViewClassification',
    'app.filament.resources.company-type-resource.pages.create-company-type' => 'App\\Filament\\Resources\\CompanyTypeResource\\Pages\\CreateCompanyType',
    'app.filament.resources.company-type-resource.pages.edit-company-type' => 'App\\Filament\\Resources\\CompanyTypeResource\\Pages\\EditCompanyType',
    'app.filament.resources.company-type-resource.pages.list-company-types' => 'App\\Filament\\Resources\\CompanyTypeResource\\Pages\\ListCompanyTypes',
    'app.filament.resources.company-type-resource.pages.view-company-type' => 'App\\Filament\\Resources\\CompanyTypeResource\\Pages\\ViewCompanyType',
    'app.filament.resources.group-resource.pages.create-group' => 'App\\Filament\\Resources\\GroupResource\\Pages\\CreateGroup',
    'app.filament.resources.group-resource.pages.edit-group' => 'App\\Filament\\Resources\\GroupResource\\Pages\\EditGroup',
    'app.filament.resources.group-resource.pages.list-groups' => 'App\\Filament\\Resources\\GroupResource\\Pages\\ListGroups',
    'app.filament.resources.group-resource.pages.view-group' => 'App\\Filament\\Resources\\GroupResource\\Pages\\ViewGroup',
    'app.filament.resources.province-resource.pages.create-province' => 'App\\Filament\\Resources\\ProvinceResource\\Pages\\CreateProvince',
    'app.filament.resources.province-resource.pages.edit-province' => 'App\\Filament\\Resources\\ProvinceResource\\Pages\\EditProvince',
    'app.filament.resources.province-resource.pages.list-provinces' => 'App\\Filament\\Resources\\ProvinceResource\\Pages\\ListProvinces',
    'app.filament.resources.province-resource.pages.view-province' => 'App\\Filament\\Resources\\ProvinceResource\\Pages\\ViewProvince',
    'app.filament.resources.sub-classification-resource.pages.create-sub-classification' => 'App\\Filament\\Resources\\SubClassificationResource\\Pages\\CreateSubClassification',
    'app.filament.resources.sub-classification-resource.pages.edit-sub-classification' => 'App\\Filament\\Resources\\SubClassificationResource\\Pages\\EditSubClassification',
    'app.filament.resources.sub-classification-resource.pages.list-sub-classifications' => 'App\\Filament\\Resources\\SubClassificationResource\\Pages\\ListSubClassifications',
    'app.filament.resources.sub-classification-resource.pages.view-sub-classification' => 'App\\Filament\\Resources\\SubClassificationResource\\Pages\\ViewSubClassification',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'app.filament.resources.user-resource.pages.view-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\ViewUser',
    'app.filament.resources.vendor-resource.pages.create-vendor' => 'App\\Filament\\Resources\\VendorResource\\Pages\\CreateVendor',
    'app.filament.resources.vendor-resource.pages.edit-vendor' => 'App\\Filament\\Resources\\VendorResource\\Pages\\EditVendor',
    'app.filament.resources.vendor-resource.pages.list-vendors' => 'App\\Filament\\Resources\\VendorResource\\Pages\\ListVendors',
    'app.filament.resources.vendor-resource.pages.view-vendor' => 'App\\Filament\\Resources\\VendorResource\\Pages\\ViewVendor',
    'app.filament.pages.auth.login-custom' => 'App\\Filament\\Pages\\Auth\\LoginCustom',
    'app.filament.pages.dashboard' => 'App\\Filament\\Pages\\Dashboard',
    'app.filament.widgets.vendor-admin-overview' => 'App\\Filament\\Widgets\\VendorAdminOverview',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Pages\\Dashboard.php' => 'App\\Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Resources\\BankResource.php' => 'App\\Filament\\Resources\\BankResource',
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Resources\\CategoryResource.php' => 'App\\Filament\\Resources\\CategoryResource',
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Resources\\CityResource.php' => 'App\\Filament\\Resources\\CityResource',
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Resources\\ClassificationResource.php' => 'App\\Filament\\Resources\\ClassificationResource',
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Resources\\CompanyTypeResource.php' => 'App\\Filament\\Resources\\CompanyTypeResource',
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Resources\\GroupResource.php' => 'App\\Filament\\Resources\\GroupResource',
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Resources\\ProvinceResource.php' => 'App\\Filament\\Resources\\ProvinceResource',
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Resources\\SubClassificationResource.php' => 'App\\Filament\\Resources\\SubClassificationResource',
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Resources\\VendorResource.php' => 'App\\Filament\\Resources\\VendorResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament\\Widgets\\VendorAdminOverview.php' => 'App\\Filament\\Widgets\\VendorAdminOverview',
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\APPLICATIONS\\ycp_supplier\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);