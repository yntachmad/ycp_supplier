<?php

namespace App\Filament\Public\Resources\VendorResource\Pages;

use App\Filament\Public\Resources\VendorResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateVendor extends CreateRecord
{
    protected static string $resource = VendorResource::class;
}
