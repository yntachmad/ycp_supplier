<img src="{{ asset('images/logo-ycp.png') }}" alt="logo" class="h-10" />
